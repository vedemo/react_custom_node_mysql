import axios from 'axios';
import { setAlert } from './alert';

import {
  CREATE_USEROFEMPLOYEE,
  CREATE_USEROFEMPLOYEE_ERROR
 
} from './types';
const baseURL = 'http://localhost:5000';
// Get current users profile

// Create or update profile
export const createUserofEmployee = (
  formData,
  history,
  edit = false
) => async dispatch => {
  try {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const res = await axios.put('/api/profile/createuserofemployee', formData, config);

    dispatch({
      type: CREATE_USEROFEMPLOYEE,
      payload: res.data
    });

    dispatch(setAlert(edit ? 'Profile Updated' : 'User Profile Created', 'success'));

    if (!edit) {
      history.push('/dashboard');
    }
  } catch (err) {
    const errors = err.response.data.errors;

    if (errors) {
      errors.forEach(error => dispatch(setAlert(error.msg, 'danger')));
    }

    dispatch({
      type: CREATE_USEROFEMPLOYEE_ERROR,
      payload: { msg: err.response.statusText, status: err.response.status }
    });
  }
};


