import {
    SHOWM_MENU
   }  from './types';

   export const loadmenu=()=> async dispatch=>{
    dispatch({
             type:SHOWM_MENU
         })
    
} 

